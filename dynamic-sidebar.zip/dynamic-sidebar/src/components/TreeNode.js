import React, { useState } from "react";
import Tree from "./Tree";
import styles from "./TreeNode.module.css";
const TreeNode = ({ node }) => {
  console.log(node);
  const { children, label, iconUrl } = node;

  const [showChildren, setShowChildren] = useState(false);

  const handleClick = () => {
    setShowChildren(!showChildren);
  };
  return (
    <>
      <li onClick={handleClick} style={{ marginBottom: "10px" }}>
        <img src={iconUrl} className={styles.icon} />
        <span>{label}</span>
      </li>
      {node.children?.length > 0 && (
        <ul style={{ paddingLeft: "10px", borderLeft: "1px solid black" }}>
          {showChildren && <Tree treeData={children} />}
        </ul>
      )}
    </>
  );
};
export default TreeNode;
