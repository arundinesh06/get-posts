import React from "react";
import TreeNode from "./TreeNode";
import styles from "./Tree.module.css";

const Tree = ({ treeData }) => {
  return (
    <ul className={styles.container}>
      {treeData.map((node) => (
        <TreeNode node={node} key={node.key} className="main-tree" />
      ))}
    </ul>
  );
};

export default Tree;
