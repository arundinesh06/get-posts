import Tree from "./components/Tree";
import "./App.css";
const treeData = [
  {
    key: "0",
    label: "src",
    iconUrl:
      "https://icons.iconarchive.com/icons/paomedia/small-n-flat/512/folder-icon.png",
    children: [
      {
        key: "0",
        label: "App.jsx",
        iconUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2300px-React-icon.svg.png",
      },
      {
        key: "1",
        label: "index.jsx",
        iconUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2300px-React-icon.svg.png",
      },
      {
        key: "2",
        label: "Style.css",
        iconUrl: "https://cdn-icons-png.flaticon.com/512/186/186319.png",
      },
    ],
  },
  {
    key: "1",
    label: "index.html",
    iconUrl: "https://cdn-icons-png.flaticon.com/512/1532/1532556.png",
    children: [],
  },
  {
    key: "2",
    label: "package.json",
    iconUrl:
      "https://icons.iconarchive.com/icons/papirus-team/papirus-mimetypes/512/app-json-icon.png",
    children: [],
  },
];

function App() {
  return (
    <div className="App">
      <div className="sidebar">
        <Tree treeData={treeData} />
      </div>
    </div>
  );
}

export default App;
